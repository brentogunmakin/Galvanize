import React, { Component }  from 'react';
import styled from 'styled-components';


const ErrorLoadingPage = () => {
    return(
        <div>
            <h1>Error that page doesn't exist in our domain.</h1>
        </div>
    )
}

export default ErrorLoadingPage;
