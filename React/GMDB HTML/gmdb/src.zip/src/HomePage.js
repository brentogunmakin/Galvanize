 import React, { Component }  from 'react';
import styled from 'styled-components';





class HomePage extends Component {
    render() {
    return(
        <div> 
            this is the homepage
        </div>

    )
    }
}

export default HomePage;